package problem7_2;

public class DemoExtendsException {

    public String validname()
    {
         return ("Name is not Valid..Please ReEnter the Name");
    }
}

