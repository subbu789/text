package com.book;

import java.util.Scanner;

public class TestBook {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("AB devilliers");
		String booktitle=sc.nextLine();
		
		System.out.println("17");
		int price=sc.nextInt();
		sc.nextLine();
		
		Book n=new Book();
		n.setBooktitile(booktitle);
		n.setBookprice(price);
		System.out.println("Book Details");
		System.out.println("Ab devilliers :"+n.getBooktitile());
		System.out.println("30 :"+n.getBookprice());
		
	}

}

